# Kotlin/Core

<#include "introduction.md">

<#include "syntax.md">

<#include "type-system.md">

<#include "builtins.md">

<#include "declarations.md">

<#include "inheritance.md">

<#include "scoping.md">

<#include "statements.md">

<#include "expressions.md">

<#include "operators.md">

<#include "packages.md">

<#include "overload-resolution.md">

<#include "cdfa.md">

<#include "type-constraints.md">

<#include "type-inference.md">

<#include "rtti.md">

<#include "exceptions.md">

<#include "annotations.md">

<#include "coroutines.md">

<#include "concurrency.md">
